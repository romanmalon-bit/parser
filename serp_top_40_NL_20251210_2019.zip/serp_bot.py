import os
import asyncio
import json
import logging
from collections import defaultdict
from pathlib import Path
from typing import Dict, Any, List, Optional

from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
    CallbackQueryHandler,
    MessageHandler,
    filters,
)

# =========================
# ІМПОРТИ ПАРСЕРА
# =========================
from parser_core import run_project, load_history

# =========================
# НАЛАШТУВАННЯ
# =========================

TELEGRAM_BOT_TOKEN = "8146349890:AAGvkkJnglQfQak0yRxX3JMGZ3zzbKSU-Eo"
PROJECTS_FILE = "projects.json"
CONFIG_FILE = "config.json"

MIN_KEYWORDS_FOR_ALERT = 4
DROP_THRESHOLD = 0.5

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# =========================
# CONFIG / SERPER KEY
# =========================

def load_config() -> Dict[str, Any]:
    path = Path(CONFIG_FILE)
    if not path.exists():
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_config(cfg: Dict[str, Any]) -> None:
    path = Path(CONFIG_FILE)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error("Не вдалося зберегти config.json:", e)


def apply_serper_key_from_config() -> None:
    cfg = load_config()
    api_key = cfg.get("serper_api_key")
    if api_key:
        os.environ["SERPER_API_KEY"] = api_key

# =========================
# ПРОЄКТИ
# =========================

def load_all_projects() -> List[Dict[str, Any]]:
    path = Path(PROJECTS_FILE)
    if not path.exists():
        raise RuntimeError("projects.json не знайдено")

    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    projects = data.get("projects", [])
    if not projects:
        raise RuntimeError("projects.json порожній")

    for p in projects:
        p.setdefault("max_positions", 30)

    return projects


PROJECTS: List[Dict[str, Any]] = []
PROJECTS_BY_NAME: Dict[str, Dict[str, Any]] = {}


def reload_projects():
    global PROJECTS, PROJECTS_BY_NAME
    PROJECTS = load_all_projects()
    PROJECTS_BY_NAME = {p["name"]: p for p in PROJECTS}

reload_projects()


def delete_project_by_name(name: str) -> bool:
    path = Path(PROJECTS_FILE)

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return False

    projects = data.get("projects", [])
    new_projects = [p for p in projects if p.get("name") != name]

    if len(new_projects) == len(projects):
        return False

    data["projects"] = new_projects

    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    reload_projects()
    return True

# =========================
# АНАЛІЗ ДРОПІВ
# =========================

def compute_domain_drop_alerts():
    history = load_history()
    if len(history) < 2:
        return []

    prev = history[-2]
    curr = history[-1]

    def parse(entry):
        mp = defaultdict(set)
        for r in entry.get("results", []):
            if not r.get("Is_Target"): continue
            mp[r["Domain"]].add(r["Keyword"])
        return mp

    p = parse(prev)
    c = parse(curr)

    alerts = []

    for domain, prev_keys in p.items():
        if len(prev_keys) <= MIN_KEYWORDS_FOR_ALERT:
            continue

        curr_keys = c.get(domain, set())
        lost = prev_keys - curr_keys

        if len(lost) >= len(prev_keys) * DROP_THRESHOLD:
            alerts.append({
                "domain": domain,
                "prev_count": len(prev_keys),
                "curr_count": len(curr_keys),
                "lost_count": len(lost),
                "lost_keywords_sample": list(lost)[:10],
            })

    return alerts

# =========================
# PATH до Excel
# =========================

def resolve_output_path(raw):
    if isinstance(raw, (str, Path)):
        return Path(raw)

    if isinstance(raw, (list, tuple)) and raw:
        if isinstance(raw[0], (str, Path)):
            return Path(raw[0])

    if isinstance(raw, dict):
        for k in ("output_file", "excel_file", "path", "file_path"):
            if k in raw:
                return Path(raw[k])

    return None

# =========================
# СТАН КОРИСТУВАЧА
# =========================

def get_user_state(context):
    ud = context.user_data
    ud.setdefault("selected_projects", set())
    ud.setdefault("pages", 3)
    ud.setdefault("awaiting_serper_key", False)
    return ud

# =========================
# КЛАВІАТУРИ
# =========================

def keyboard_main(state):
    pages = state["pages"]
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🧩 Обрати проєкти", callback_data="choose")],
        [InlineKeyboardButton(f"📄 Кількість сторінок ({pages})", callback_data="pages")],
        [InlineKeyboardButton("▶️ Запустити парсинг", callback_data="run")],
        [InlineKeyboardButton("🗑 Видалити проєкт", callback_data="delete")],
        [InlineKeyboardButton("🔑 Змінити Serper.dev API key", callback_data="api")],
    ])

def keyboard_projects(state):
    sel = state["selected_projects"]
    rows = []
    for name in PROJECTS_BY_NAME:
        mark = "✅" if name in sel else "⚪"
        rows.append([InlineKeyboardButton(f"{mark} {name}", callback_data=f"proj:{name}")])

    rows.append([
        InlineKeyboardButton("🔘 Вибрати всі", callback_data="all"),
        InlineKeyboardButton("♻ Очистити", callback_data="none")
    ])
    rows.append([InlineKeyboardButton("⬅ Назад", callback_data="back")])
    return InlineKeyboardMarkup(rows)

def keyboard_delete():
    rows = []
    for name in PROJECTS_BY_NAME:
        rows.append([InlineKeyboardButton(f"🗑 {name}", callback_data=f"askdel:{name}")])
    rows.append([InlineKeyboardButton("⬅ Назад", callback_data="back")])
    return InlineKeyboardMarkup(rows)

def keyboard_confirm_delete(name):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Так, видалити", callback_data=f"del:{name}")],
        [InlineKeyboardButton("❌ Назад", callback_data="delete")],
    ])

def keyboard_pages(state):
    current = state["pages"]
    rows = []
    row = []
    for p in [1,2,3,5,10]:
        label = f"{'✅' if p==current else ''} {p}"
        row.append(InlineKeyboardButton(label, callback_data=f"p:{p}"))
        if len(row)==3:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([InlineKeyboardButton("⬅ Назад", callback_data="back")])
    return InlineKeyboardMarkup(rows)

# =========================
# КОМАНДИ
# =========================

async def start(update, context):
    st = get_user_state(context)
    await update.effective_chat.send_message(
        "👋 Привіт! Обери дію:",
        reply_markup=keyboard_main(st)
    )

async def help(update, context):
    await update.effective_chat.send_message(
        "Це бот-парсер. Додавання проектів робиться **лише локально у Streamlit**.",
        parse_mode="HTML"
    )

async def menu(update, context):
    st = get_user_state(context)
    await update.effective_chat.send_message(
        "Головне меню:",
        reply_markup=keyboard_main(st)
    )

async def set_api(update, context):
    st = get_user_state(context)
    if context.args:
        key = " ".join(context.args).strip()
        cfg = load_config()
        cfg["serper_api_key"] = key
        save_config(cfg)
        os.environ["SERPER_API_KEY"] = key
        await update.effective_chat.send_message("🔑 API KEY оновлено.")
    else:
        st["awaiting_serper_key"] = True
        await update.effective_chat.send_message("Введи новий API KEY одним повідомленням:")

# =========================
# CALLBACK
# =========================

async def callback(update, context):
    query = update.callback_query
    await query.answer()

    data = query.data
    st = get_user_state(context)

    # -------- проекти --------
    if data == "choose":
        await query.edit_message_text("Обери проєкти:", reply_markup=keyboard_projects(st))
        return

    if data.startswith("proj:"):
        name = data.split(":",1)[1]
        if name in st["selected_projects"]:
            st["selected_projects"].remove(name)
        else:
            st["selected_projects"].add(name)
        await query.edit_message_reply_markup(keyboard_projects(st))
        return

    if data == "all":
        st["selected_projects"] = set(PROJECTS_BY_NAME.keys())
        await query.edit_message_reply_markup(keyboard_projects(st))
        return

    if data == "none":
        st["selected_projects"] = set()
        await query.edit_message_reply_markup(keyboard_projects(st))
        return

    # -------- видалення --------
    if data == "delete":
        await query.edit_message_text("Оберіть проєкт:", reply_markup=keyboard_delete())
        return

    if data.startswith("askdel:"):
        name = data.split(":",1)[1]
        await query.edit_message_text(
            f"Точно видалити «{name}»?",
            reply_markup=keyboard_confirm_delete(name)
        )
        return

    if data.startswith("del:"):
        name = data.split(":",1)[1]
        ok = delete_project_by_name(name)
        if name in st["selected_projects"]:
            st["selected_projects"].remove(name)
        await query.edit_message_text(
            f"{'✅ Видалено' if ok else '⚠ Не знайдено'}\n\nОберіть інший проєкт:",
            reply_markup=keyboard_delete()
        )
        return

    # -------- сторінки --------
    if data == "pages":
        await query.edit_message_text("Скільки сторінок парсити?", reply_markup=keyboard_pages(st))
        return

    if data.startswith("p:"):
        st["pages"] = int(data.split(":",1)[1])
        await query.edit_message_reply_markup(keyboard_pages(st))
        return

    # -------- API KEY --------
    if data == "api":
        st["awaiting_serper_key"] = True
        await query.edit_message_text("🔑 Введи новий API ключ:")
        return

    # -------- назад --------
    if data == "back":
        await query.edit_message_text("Головне меню:", reply_markup=keyboard_main(st))
        return

    # -------- запуск парсингу --------
    if data == "run":
        await handle_run(update, context, query)
        return

# =========================
# ПАРСИНГ
# =========================

async def handle_run(update, context, query):
    st = get_user_state(context)
    chat = query.message.chat_id

    if not st["selected_projects"]:
        await query.edit_message_text("⚠ Спочатку обери проєкти!", reply_markup=keyboard_main(st))
        return

    pages = st["pages"]
    max_positions = pages * 10

    plist = "\n".join("• "+p for p in st["selected_projects"])
    await query.edit_message_text(
        f"🚀 Запускаю парсинг:\n{plist}\n\nГлибина: {pages} сторінок...",
    )

    asyncio.create_task(run_for_user(chat, context, st["selected_projects"], pages))


async def run_for_user(chat_id, context, projects, pages):
    max_positions = pages * 10

    try:
        await context.bot.send_message(chat_id, "▶ Починаю...")

        for name in projects:
            p = PROJECTS_BY_NAME.get(name)
            if not p:
                await context.bot.send_message(chat_id, f"❌ Проєкт {name} не знайдено!")
                continue

            cfg = dict(p)
            cfg["max_positions"] = max_positions

            await context.bot.send_message(chat_id, f"⏳ Парсю {name}...")

            raw = await run_project(cfg)
            path = resolve_output_path(raw)

            if not path or not path.exists():
                await context.bot.send_message(chat_id,
                    f"⚠ Не знайдено Excel для {name}.\nОтримано: {raw}")
                continue

            alerts = compute_domain_drop_alerts()
            if alerts:
                msg = ["⚠ <b>ALARM</b>:"]
                for a in alerts:
                    msg.append(
                        f"<code>{a['domain']}</code>: було {a['prev_count']}, стало {a['curr_count']}"
                    )
                await context.bot.send_message(chat_id, "\n".join(msg), parse_mode="HTML")

            with path.open("rb") as f:
                await context.bot.send_document(
                    chat_id,
                    document=f,
                    filename=path.name,
                    caption=f"Звіт по {name}"
                )

        await context.bot.send_message(chat_id, "🏁 Готово.")

    except Exception as e:
        await context.bot.send_message(chat_id, f"❌ Помилка: {e}")

# =========================
# ТЕКСТОВІ ПОВІДОМЛЕННЯ
# =========================

async def incoming_text(update, context):
    st = get_user_state(context)
    text = update.effective_message.text.strip()

    if st["awaiting_serper_key"]:
        st["awaiting_serper_key"] = False
        cfg = load_config()
        cfg["serper_api_key"] = text
        save_config(cfg)
        os.environ["SERPER_API_KEY"] = text
        await update.effective_chat.send_message("🔑 API KEY оновлено.")
        return

# =========================
# MAIN
# =========================

def main():
    apply_serper_key_from_config()

    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("menu", menu))
    app.add_handler(CommandHandler("help", help))
    app.add_handler(CommandHandler("set_api", set_api))

    app.add_handler(CallbackQueryHandler(callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, incoming_text))

    app.run_polling()

if __name__ == "__main__":
    main()
